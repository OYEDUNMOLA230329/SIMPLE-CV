public class Simple {

    
    public static void main(String[] args) {
         // Personal information
    String name = "Alao Oyedunmola Leah";
    String matric ="ND/230329";
    String email= "alaooyedunmola2022@gmail.com";
    String phone = "08130695976";
    String address ="Autine area,Oyo State";
    
    //Education
    String univerity ="Oyo State College of Agriculture And Technology";
    String degree = "(phd Computer Science)";
    String graduationYear = "Expected Graduation:2024";
    
    // Skills
    String[] skills = {"Java Programming","Network Security","Problem Solving","Teamwork","Communication"};
    

    
    // Experience
    String jobTitle = "Intern Software Developer";
    String companyName ="Tech Solutions Ltd";
    String jobDuration = "June2023- August 2023";
    String jobDescription = "Worked on developing and optimizing software solutions for various clients";
    
    // Printing the CV
    System.out.println("---- Curriculum Vitae---");
    System.out.println("Alao Oyedunmola Leah");
    System.out.println("ND/230329");
    System.out.println("alaooyedunmola2022@gmail.com");
    System.out.println("08130695976");
    System.out.println("Autine area,Oyo State");
    
    System.out.println("Education");
    System.out.println("Oyo State College Of Agricultyre And Technology");
    System.out.println("computer cience");
    System.out.println("2023");
    System.out.println();
    
    System.out.println("skill");

    for (String skill : skills){
         System.out.println("-"+skill);
    }
    System.out.println();
    
    System.out.println("Experience");
    System.out.println(jobTitle);
    System.out.println(companyName);
    System.out.println(jobDuration);
    System.out.println(jobDescription);
    System.out.println("-----------");
    
    
    }
          
}
    
    
    
    
